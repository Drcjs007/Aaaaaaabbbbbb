﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N_m3u8DL_RE.Common.Enum
{
    public enum Choise
    {
        YES = 1,
        NO = 0
    }
}
