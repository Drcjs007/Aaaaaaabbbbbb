﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N_m3u8DL_RE.Common.Log
{
    public enum LogLevel
    {
        OFF,
        ERROR,
        WARN,
        INFO,
        DEBUG,
    }
}
